package StrategyPatternExample;

public class Main {
    public static void main(String[] args) {
        // Create a payment context
        PaymentContext paymentContext = new PaymentContext();

        // Use Credit Card Payment
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234567890123456", "John Doe", "123", "12/23");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.executePayment(250.00);

        // Use PayPal Payment
        PaymentStrategy payPalPayment = new PayPalPayment("john.doe@example.com", "password123");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.executePayment(150.00);
    }
}
