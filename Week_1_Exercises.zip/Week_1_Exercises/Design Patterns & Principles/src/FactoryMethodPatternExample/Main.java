package FactoryMethodPatternExample;

public class Main {
    public static void main(String[] args) {
        // Create factories for each document type
        DocumentFactory wordFact = new WordDocumentFactory();
        DocumentFactory pdfFact = new PdfDocumentFactory();
        DocumentFactory excelFact = new ExcelDocumentFactory();

        // Create documents using the factories
        Document wordDoc = wordFact.createDocument();
        Document pdfDoc = pdfFact.createDocument();
        Document excelDoc = excelFact.createDocument();

        // Test the created documents
        wordDoc.open();
        wordDoc.save();
        wordDoc.close();

        pdfDoc.open();
        pdfDoc.save();
        pdfDoc.close();

        excelDoc.open();
        excelDoc.save();
        excelDoc.close();
    }
}
