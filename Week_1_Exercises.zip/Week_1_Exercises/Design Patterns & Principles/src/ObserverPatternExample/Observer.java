package ObserverPatternExample;

public interface Observer {
    void update(String stockSymbol, double stockPrice);
}
