package ObserverPatternExample;

public class Main {
    public static void main(String[] args) {
        // Create a stock market subject
        StockMarket stockMarket = new StockMarket("AAPL", 150.00);

        // Create observers
        Observer mobileApp1 = new MobileApp("Mobile App 1");
        Observer webApp1 = new WebApp("Web App 1");

        // Register observers
        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(webApp1);

        // Change stock price and notify observers
        stockMarket.setStockPrice(155.00);
        System.out.println("");

        // Deregister one observer and change stock price again
        stockMarket.removeObserver(webApp1);
        stockMarket.setStockPrice(160.00);
    }
}
