package AdapterPatternExample;

public class Main {
    public static void main(String[] args) {
        // Create instances of payment gateways
        GPay gpay = new GPay();
        PhonePe phonepe = new PhonePe();

        // Create adapter instances
        PaymentProcessor GPayAdapter = new GPayAdapter(gpay);
        PaymentProcessor PhonePeAdapter = new PhonePeAdapter(phonepe);

        // Process payments through adapters
        GPayAdapter.processPayment(100.0);
        PhonePeAdapter.processPayment(200.0);
    }
}
