package DecoratorPatternExample;

public class Main {
    public static void main(String[] args) {
        // Create the basic notifier
        Notifier notifier = new EmailNotifier();

        // Decorate it with SMS notifier
        notifier = new SMSNotifierDecorator(notifier);

        // Further decorate it with Slack notifier
        notifier = new SlackNotifierDecorator(notifier);

        // Send a notification using the decorated notifier
        notifier.send("Hello, this is a test notification!");
    }
}
