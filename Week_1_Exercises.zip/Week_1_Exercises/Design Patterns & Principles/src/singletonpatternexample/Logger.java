package singletonpatternexample;

public class Logger {
    // Private static variable to hold the single instance of the class
    private static Logger singleInstance = null;

    // Private constructor to prevent instantiation
    private Logger() {
        // Initialization code here
    }

    // Public static method to provide access to the instance
    public static Logger getInstance() {
        if (singleInstance == null) {
            // Synchronized block to remove overhead
            synchronized (Logger.class) {
                if (singleInstance == null) {
                    // If instance is null, initialize
                    singleInstance = new Logger();
                }
            }
        }
        return singleInstance;
    }

    // Method to log messages
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}
