package LibraryManagementSystem;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book("1", "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Book("2", "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book("3", "1984", "George Orwell"));
        books.add(new Book("4", "Pride and Prejudice", "Jane Austen"));

        // Sort books by title for binary search
        Collections.sort(books, Comparator.comparing(Book::getTitle));

        LibraryManagementSystem library = new LibraryManagementSystem();

        // Test linear search
        System.out.println("Linear Search:");
        Book foundBook = library.linearSearchByTitle(books, "1984");
        System.out.println(foundBook != null ? "Found: " + foundBook : "Book not found");

        // Test binary search
        //System.out.println("\nBinary Search:");
        //foundBook = library.binarySearchByTitle(books, "1984");
        //System.out.println(foundBook != null ? "Found: " + foundBook : "Book not found");
    }
}
