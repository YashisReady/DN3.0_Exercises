package Sorting_Customer_Orders;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("001", "Alice", 150.50),
            new Order("002", "Bob", 99.99),
            new Order("003", "Charlie", 200.00),
            new Order("004", "David", 120.75)
        };

        // Bubble Sort
        System.out.println("Bubble Sort:");
        BubbleSort.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        // Quick Sort
        System.out.println("\nQuick Sort:");
        Order[] ordersForQuickSort = {
            new Order("001", "Alice", 150.50),
            new Order("002", "Bob", 99.99),
            new Order("003", "Charlie", 200.00),
            new Order("004", "David", 120.75)
        };
        QuickSort.quickSort(ordersForQuickSort, 0, ordersForQuickSort.length - 1);
        for (Order order : ordersForQuickSort) {
            System.out.println(order);
        }
    }
}
