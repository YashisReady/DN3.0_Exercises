package E_CommerceSearchFunction;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("101", "Laptop", "Electronics"),
            new Product("102", "Smartphone", "Electronics"),
            new Product("103", "Shirt", "Apparel"),
            new Product("104", "Book", "Books")
        };

        // Linear search test
        System.out.println("Linear Search Result:");
        Product foundProduct = LinearSearch.linearSearch(products, "Smartphone");
        if (foundProduct != null) {
            System.out.println("Product found: " + foundProduct);
        } else {
            System.out.println("Product not found.");
        }

        // Binary search test
        System.out.println("\nBinary Search Result:");
        foundProduct = BinarySearch.binarySearch(products, "Smartphone");
        if (foundProduct != null) {
            System.out.println("Product found: " + foundProduct);
        } else {
            System.out.println("Product not found.");
        }
    }
}
