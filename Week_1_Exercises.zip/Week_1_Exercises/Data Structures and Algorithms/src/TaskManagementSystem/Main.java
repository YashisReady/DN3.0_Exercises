package TaskManagementSystem;

public class Main {
    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();

        // Adding tasks
        system.addTask(new Task("T001", "Task 1", "Pending"));
        system.addTask(new Task("T002", "Task 2", "Completed"));
        system.addTask(new Task("T003", "Task 3", "In Progress"));

        // Traversing tasks
        System.out.println("Task List:");
        system.traverseTasks();

        // Searching for a task
        System.out.println("\nSearching for task with ID T002:");
        Task task = system.searchTask("T002");
        if (task != null) {
            System.out.println("Task found: " + task);
        } else {
            System.out.println("Task not found.");
        }

        // Deleting a task
        System.out.println("\nDeleting task with ID T003:");
        system.deleteTask("T003");

        // Traversing tasks after deletion
        System.out.println("\nTask List after deletion:");
        system.traverseTasks();
    }
}

