package EmployeeManagementSystem;

public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(10);

        // Adding employees
        system.addEmployee(new Employee("E001", "Alice", "Manager", 75000));
        system.addEmployee(new Employee("E002", "Bob", "Developer", 60000));
        system.addEmployee(new Employee("E003", "Charlie", "Designer", 50000));

        // Traversing employees
        System.out.println("Employee List:");
        system.traverseEmployees();

        // Searching for an employee
        System.out.println("\nSearching for employee with ID E002:");
        Employee employee = system.searchEmployee("E002");
        if (employee != null) {
            System.out.println("Employee found: " + employee);
        } else {
            System.out.println("Employee not found.");
        }

        // Deleting an employee
        System.out.println("\nDeleting employee with ID E003:");
        system.deleteEmployee("E003");

        // Traversing employees after deletion
        System.out.println("\nEmployee List after deletion:");
        system.traverseEmployees();
    }
}
