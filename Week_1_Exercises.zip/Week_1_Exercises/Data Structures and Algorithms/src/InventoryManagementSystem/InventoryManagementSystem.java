package InventoryManagementSystem;

import java.util.HashMap;
import java.util.Map;

public class InventoryManagementSystem {
    private Map<String, Product> inventory;

    public InventoryManagementSystem() {
        inventory = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    // Method to update a product
    public void updateProduct(String productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    // Method to display all products
    public void displayProducts() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        
        // Adding products
        Product product1 = new Product("101", "Laptop", 10, 999.99);
        Product product2 = new Product("102", "Smartphone", 25, 599.99);

        ims.addProduct(product1);
        ims.addProduct(product2);

        // Displaying products
        System.out.println("Current Inventory:");
        ims.displayProducts();

        // Updating a product
        Product updatedProduct = new Product("101", "Laptop", 15, 949.99);
        ims.updateProduct("101", updatedProduct);

        // Displaying products after update
        System.out.println("\nInventory after update:");
        ims.displayProducts();

        // Deleting a product
        ims.deleteProduct("102");

        // Displaying products after deletion
        System.out.println("\nInventory after deletion:");
        ims.displayProducts();
    }
}
